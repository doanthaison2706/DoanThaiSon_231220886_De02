﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace dts_231220886_de02.Models;

public partial class DtsDbContext : DbContext
{
    public DtsDbContext()
    {
    }

    public DtsDbContext(DbContextOptions<DtsDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<DtsCatalog> DtsCatalogs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=172.16.191.1,1433;Database=DoanThaiSon_231220886_de02;User Id=sa;Password=123456aA@$;MultipleActiveResultSets=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DtsCatalog>(entity =>
        {
            entity.HasKey(e => e.DtsId).HasName("PK__DtsCatal__B8DDA9695AD3700F");

            entity.ToTable("DtsCatalog");

            entity.Property(e => e.DtsId)
                .HasMaxLength(20)
                .HasColumnName("dtsId");
            entity.Property(e => e.DtsCateActive).HasColumnName("dtsCateActive");
            entity.Property(e => e.DtsCateName)
                .HasMaxLength(50)
                .HasColumnName("dtsCateName");
            entity.Property(e => e.DtsCatePicture)
                .HasMaxLength(100)
                .HasColumnName("dtsCatePicture");
            entity.Property(e => e.DtsCatePrice).HasColumnName("dtsCatePrice");
            entity.Property(e => e.DtsCateQty).HasColumnName("dtsCateQty");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
